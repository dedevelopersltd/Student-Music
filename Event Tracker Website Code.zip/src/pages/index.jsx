import Home  from "./home";
import Dashboard from "./Dashboard";
import ArtistDetails from "./ArtistDetails";
import TourDetails from "./TourDetails";

export { Home, Dashboard, ArtistDetails, TourDetails };
